from nltk.corpus import wordnet as wn
import json
# Countries with two words or more should be delimited with $_ for WordNet
# $ wn United_Kingdom -synsn
# (TCountryOrganization @ 'UN.M49') sortedCountryNames 
country_list = ['Afghanistan','Albania','Algeria','American_Samoa','Andorra','Angola','Anguilla','Antigua_and_Barbuda','Argentina','Armenia','Aruba','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Belize','Benin','Bermuda','Bhutan','Bolivia','Bonaire_Saint_Eustatius_and_Saba','Bosnia_and_Herzegovina','Botswana','Brazil','British_Virgin_Islands','Brunei_Darussalam','Bulgaria','Burkina_Faso','Burundi','Cambodia','Cameroon','Canada','Cape_Verde','Cayman_Islands','Central_African_Republic','Central_Asia','Chad','Channel_Islands','Chile','China','Hong_Kong','Macao','Colombia','Comoros','Congo','Cook_Islands','Costa_Rica','Cote_d''Ivoire','Croatia','Cuba','Curacao','Cyprus','Czech_Republic','Democratic_People''s_Republic_of_Korea','Democratic_Republic_of_the_Congo','Denmark','Djibouti','Dominica','Dominican_Republic','Ecuador','Egypt','El_Salvador','Equatorial_Guinea','Eritrea','Estonia','Ethiopia','Faeroe_Islands','Malvinas','Fiji','Finland','France','French_Guiana','French_Polynesia','Gabon','Gambia','Georgia','Germany','Ghana','Gibraltar','Greece','Greenland','Grenada','Guadeloupe','Guam','Guatemala','Guernsey','Guinea','Guinea-Bissau','Guyana','Haiti','Holy_See','Honduras','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Isle_of_Man','Israel','Italy','Jamaica','Japan','Jersey','Jordan','Kazakhstan','Kenya','Kiribati','Kuwait','Kyrgyzstan','Lao_People''s_Democratic_Republic','Latvia','Lebanon','Lesotho','Liberia','Libyan_Arab_Jamahiriya','Liechtenstein','Lithuania','Luxembourg','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Marshall_Islands','Martinique','Mauritania','Mauritius','Mayotte','Mexico','Micronesia','Monaco','Mongolia','Montenegro','Montserrat','Morocco','Mozambique','Myanmar','Namibia','Nauru','Nepal','Netherlands','New_Caledonia','New_Zealand','Nicaragua','Niger','Nigeria','Niue','Norfolk_Island','Northern_Mariana_Islands','Norway','Occupied_Palestinian_Territory','Oman','Pakistan','Palau','Panama','Papua_New_Guinea','Paraguay','Peru','Philippines','Pitcairn','Poland','Portugal','Puerto_Rico','Qatar','Korea','Moldova','Reunion','Romania','Russian_Federation','Rwanda','Saint_Helena','Saint_Kitts_and_Nevis','Saint_Lucia','Saint_Maarten','Saint_Martin','Saint_Pierre_and_Miquelon','Saint_Vincent_and_the_Grenadines','Saint-Barthelemy','Samoa','San_Marino','Sao_Tome_and_Principe','Sark','Saudi_Arabia','Senegal','Serbia','Seychelles','Sierra_Leone','Singapore','Slovakia','Slovenia','Solomon_Islands','Somalia','South_Africa','Spain','Sri_Lanka','Sudan','Suriname','Svalbard_and_Jan_Mayen_Islands','Swaziland','Sweden','Switzerland','Syrian_Arab_Republic','Tajikistan','Thailand','Macedonia','Timor-Leste','Togo','Tokelau','Tonga','Trinidad_and_Tobago','Tunisia','Turkey','Turkmenistan','Turks_and_Caicos_Islands','Tuvalu','Uganda','Ukraine','United_Arab_Emirates','United_Kingdom','Tanzania','United_States','Uruguay','Uzbekistan','Vanuatu','Venezuela','VietNam','Wallis_and_Futuna_Islands','Western_Sahara','Yemen','Zambia','Zimbabwe']
f = open('c:\\pharo3.0\\output.json', 'w')
syn_list = []
# >>> for synset in wn.synsets('Singapore'):
#  wn_syn_list = [ w.replace ("_", " ") for w in synset.lemma_names ]
#  print wn_syn_list
#  
# ['Singapore', 'capital of Singapore']
# ['Singapore', 'Republic of Singapore']
# ['Singapore', 'Singapore Island']

for country_name in country_list:
    synset_list =[]
    for synset in wn.synsets(country_name):
        wn_syn_list = [ w.replace ("_", " ") for w in synset.lemma_names ]
        # Append in one list for countries with multiple synsets
        for syn in wn_syn_list:
                synset_list.append(syn)
    # Remove duplicates
    uniq_syns = list(set(synset_list))
    # Append in output list if not empty
    if uniq_syns:
        syn_list.append(uniq_syns)
json.dump(syn_list, f)
f.close()



